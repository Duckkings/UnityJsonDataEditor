using UnityEngine;

namespace GameFramework
{
    /// <summary>
    /// 业务模块接口。所有需要由 RootTickRunner 调度的系统模块必须实现该接口。
    /// 模块名称应与数据表 systemInitOrder 中的 name 字段一致。
    /// Init 方法在系统完成基础模块初始化并且所有模块注册后由 RootTickRunner 调用；
    /// Tick 方法在每帧的 Update 或 LateUpdate 中调用，由 ticktype 决定。
    /// </summary>
    public interface ISystemModule
    {
        /// <summary>
        /// 模块名称，需要与 systemInitOrder 数据表中的 name 字段保持一致。
        /// 例如表格中定义了 "battlesystem"，则模块实现的 Name 属性也应返回 "battlesystem"。
        /// </summary>
        string Name { get; }

        /// <summary>
        /// 模块初始化入口。在所有模块都完成注册之后，由 RootTickRunner 按顺序调用。
        /// 在此方法中可以安全地访问 RootTickRunner、EventBus 及数据库。
        /// </summary>
        /// <param name="root">根对象 RootTickRunner，提供模块注册、生命周期管理以及其他服务。</param>
        /// <param name="eventBus">事件总线实例，用于订阅和发布事件。</param>
        void Init(RootTickRunner root, EventBus eventBus);

        /// <summary>
        /// 每帧调用的逻辑更新。实际是在 RootTickRunner 的 Update 或 LateUpdate 中根据 ticktype 调度。
        /// 请在此实现模块的帧更新逻辑，不要在 MonoBehaviour.Update() 中直接实现，以避免框架外调用。
        /// </summary>
        void Tick();
    }
}