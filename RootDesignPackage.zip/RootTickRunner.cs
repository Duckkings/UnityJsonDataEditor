using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace GameFramework
{
    /// <summary>
    /// 根模块与 TickRunner 的实现。
    /// 此脚本负责：
    /// 1. 在 Awake 阶段初始化基础模块，包括数据库(DataEntityRuntimeLoader)与事件总线(EventBus)。
    /// 2. 将基础服务（数据库、事件总线）注册到服务字典，并读取 systemInitOrder 数据表，解析出各业务模块的初始化顺序和 Tick 类型。
    /// 3. 提供 RegisterModule 方法供业务模块在其 Start() 中注册自己，注册时会自动将该模块放入服务字典。
    /// 4. 当所有模块注册完成后，按顺序调用各模块的 Init() 方法，并记录初始化完成日志。
    /// 5. 提供 RegisterService/GetService 接口使业务系统之间能够根据名称互相引用其它模块或基础服务。
    /// 6. 在 Update 和 LateUpdate 中按照表格顺序调度各模块的 Tick()。
    /// 
    /// 使用方法：
    /// * 将此脚本添加到场景中的某个 GameObject 上（建议单例），并在 Inspector 上配置 EventBus 的表模板。
    /// * 确保项目的 dataEntity 目录中存在 systemInitOrder.json，包含字段 id (int), name (string), ticktype (int)。
    /// * 在游戏启动时会自动执行 DataEntityRuntimeLoader.Initialize()，不需要手动调用。
    /// * 每个业务模块需实现 ISystemModule，并在自身 Start() 中调用 RootTickRunner.Instance.RegisterModule(this)。
    /// * ticktype 为 0 的模块在 Update 中 Tick，为 1 的模块在 LateUpdate 中 Tick。
    /// 
    /// 日志说明：
    /// - 基础模块初始化完成后输出一条日志 `[RootTickRunner] 基础模块初始化完成`。
    /// - 每个模块初始化完成后输出 `[RootTickRunner] 模块 '<Name>' 初始化完成`。
    /// - 所有业务模块初始化完成后输出 `[RootTickRunner] 所有业务模块初始化完成`。
    /// </summary>
    public class RootTickRunner : MonoBehaviour
    {
        /// <summary>
        /// 单例实例。保证全局只有一个 RootTickRunner。
        /// </summary>
        public static RootTickRunner Instance { get; private set; }

        /// <summary>
        /// 内部记录每个模块的信息：初始化顺序、tick 类型、实例和注册状态。
        /// </summary>
        private class ModuleEntry
        {
            public int order;
            public int tickType;
            public ISystemModule module;
            public bool registered;
        }

        // 通过 systemInitOrder 表解析得到的模块表
        private readonly Dictionary<string, ModuleEntry> moduleTable = new Dictionary<string, ModuleEntry>();

        // 用于跨模块引用的服务字典。键为字符名称（模块名或服务名），值为实例引用。
        // 业务模块可通过 GetService<T>(name) 获取其它模块或服务的引用。
        private readonly Dictionary<string, object> serviceMap = new Dictionary<string, object>();

        // 事件总线实例
        private EventBus eventBus;

        // 标记初始化完成的状态
        private bool baseInitialised = false;
        private bool modulesInitialised = false;

        /// <summary>
        /// 向内部服务字典注册一个服务实例。键与实例名称应唯一对应。
        /// 如果名称已存在，会覆盖之前的引用。
        /// </summary>
        /// <param name="name">服务名或模块名。</param>
        /// <param name="instance">要注册的实例。</param>
        public void RegisterService(string name, object instance)
        {
            if (string.IsNullOrEmpty(name) || instance == null)
            {
                return;
            }
            serviceMap[name] = instance;
        }

        /// <summary>
        /// 根据名称获取服务实例，并尝试转换为指定类型。
        /// 当找不到指定名称或类型不匹配时返回 null。
        /// </summary>
        /// <typeparam name="T">希望获取的类型。</typeparam>
        /// <param name="name">服务名或模块名。</param>
        /// <returns>对应的实例或 null。</returns>
        public T GetService<T>(string name) where T : class
        {
            if (serviceMap.TryGetValue(name, out var obj))
            {
                return obj as T;
            }
            return null;
        }

        void Awake()
        {
            // 保证单例
            if (Instance != null)
            {
                Destroy(gameObject);
                return;
            }
            Instance = this;
            DontDestroyOnLoad(gameObject);

            // 初始化基础模块
            InitBaseModules();
        }

        /// <summary>
        /// 初始化数据库和事件总线，并加载 systemInitOrder 表。
        /// </summary>
        private void InitBaseModules()
        {
            // 初始化运行时数据表系统。该调用必须在读取数据前执行【55977470532208†L306-L317】。
            DataEntityRuntimeLoader.Initialize();

            // 获取或添加 EventBus 组件
            eventBus = GetComponent<EventBus>();
            if (eventBus == null)
            {
                eventBus = gameObject.AddComponent<EventBus>();
            }

            // 调用 EventBus.Init() 从数据库加载事件和标签定义。需要先配置 eventTableTemplateName 等字段。
            eventBus.Init(DataEntityRuntimeLoader);

            // 将基础服务注入服务字典，供其它模块引用。
            // 使用简单的字符串键表示服务类型。
            RegisterService("eventbus", eventBus);
            RegisterService("database", DataEntityRuntimeLoader);

            // 读取 systemInitOrder 表，构建模块表
            LoadSystemInitOrder();

            baseInitialised = true;
            Debug.Log("[RootTickRunner] 基础模块初始化完成");
        }

        /// <summary>
        /// 读取 systemInitOrder 表，解析每个模块的顺序和 Tick 类型。
        /// </summary>
        private void LoadSystemInitOrder()
        {
            var schema = DataEntityRuntimeLoader.GetSchema("systemInitOrder");
            if (schema == null || schema.instances == null)
            {
                Debug.LogError("[RootTickRunner] 未找到 systemInitOrder 表或表内没有实例");
                return;
            }
            moduleTable.Clear();
            foreach (var kvp in schema.instances)
            {
                var inst = kvp.Value;
                int order = inst.GetInt("id", 0);
                string name = inst.GetString("name", null);
                int tickType = inst.GetInt("ticktype", 0);
                if (string.IsNullOrEmpty(name))
                {
                    Debug.LogWarning("[RootTickRunner] systemInitOrder 表中存在空名称实例，已跳过");
                    continue;
                }
                if (!moduleTable.ContainsKey(name))
                {
                    moduleTable[name] = new ModuleEntry { order = order, tickType = tickType, module = null, registered = false };
                }
                else
                {
                    Debug.LogWarning($"[RootTickRunner] systemInitOrder 表存在重复名称 '{name}'，已忽略后续条目");
                }
            }
        }

        /// <summary>
        /// 业务模块在自身 Start() 中调用此方法进行注册。
        /// 注册后会检查是否所有模块都注册完成，如果是则立即初始化。
        /// </summary>
        /// <param name="module">业务模块实例，实现 ISystemModule。</param>
        public void RegisterModule(ISystemModule module)
        {
            if (module == null)
            {
                Debug.LogError("[RootTickRunner] RegisterModule 参数为空");
                return;
            }
            if (!moduleTable.TryGetValue(module.Name, out var entry))
            {
                Debug.LogError($"[RootTickRunner] 未在 systemInitOrder 表中找到模块 '{module.Name}'");
                return;
            }
            if (entry.registered)
            {
                Debug.LogWarning($"[RootTickRunner] 模块 '{module.Name}' 已经注册，重复注册已忽略");
                return;
            }
            entry.module = module;
            entry.registered = true;
            Debug.Log($"[RootTickRunner] 模块 '{module.Name}' 已注册");

            // 将该模块注入服务字典，方便其他模块通过名称获取引用
            RegisterService(module.Name, module);

            // 检查所有模块是否注册完成
            CheckAndInitAllModules();
        }

        /// <summary>
        /// 检查所有模块是否都已注册。只有当全部注册完成并且尚未初始化模块时，才会触发初始化。
        /// </summary>
        private void CheckAndInitAllModules()
        {
            if (modulesInitialised) return;
            foreach (var entry in moduleTable.Values)
            {
                if (!entry.registered) return;
            }
            // 全部注册完成
            InitAllModules();
        }

        /// <summary>
        /// 按照模块的 order 顺序初始化所有模块，并输出日志。
        /// </summary>
        private void InitAllModules()
        {
            modulesInitialised = true;
            var ordered = moduleTable.Values.OrderBy(e => e.order).ToList();
            foreach (var entry in ordered)
            {
                try
                {
                    entry.module.Init(this, eventBus);
                    Debug.Log($"[RootTickRunner] 模块 '{entry.module.Name}' 初始化完成");
                }
                catch (Exception ex)
                {
                    Debug.LogError($"[RootTickRunner] 初始化模块 '{entry.module.Name}' 时出现异常: {ex}");
                }
            }
            Debug.Log("[RootTickRunner] 所有业务模块初始化完成");
        }

        void Update()
        {
            if (!modulesInitialised) return;
            // 逐个按顺序调用 ticktype 为 0 的模块
            foreach (var entry in moduleTable.Values.OrderBy(e => e.order))
            {
                if (entry.tickType == 0 && entry.module != null)
                {
                    entry.module.Tick();
                }
            }
        }

        void LateUpdate()
        {
            if (!modulesInitialised) return;
            // 逐个按顺序调用 ticktype 为 1 的模块
            foreach (var entry in moduleTable.Values.OrderBy(e => e.order))
            {
                if (entry.tickType == 1 && entry.module != null)
                {
                    entry.module.Tick();
                }
            }
        }
    }
}